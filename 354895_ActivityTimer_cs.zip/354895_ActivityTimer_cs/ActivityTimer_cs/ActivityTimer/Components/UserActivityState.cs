using System;
using System.Collections.Generic;
using System.Text;

namespace ActivityTimer.Components
{
    public enum UserActivityState
    {
        Unknown = -1,
        Inactive = 0,
        Active = 1
    }
}
